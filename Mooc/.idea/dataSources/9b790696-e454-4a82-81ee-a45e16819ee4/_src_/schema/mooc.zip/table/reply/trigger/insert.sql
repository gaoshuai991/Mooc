CREATE TRIGGER `insert`
AFTER INSERT ON reply
FOR EACH ROW
  BEGIN
    UPDATE count SET replycount=replycount+1 WHERE msgid=new.msgid;
  END;
