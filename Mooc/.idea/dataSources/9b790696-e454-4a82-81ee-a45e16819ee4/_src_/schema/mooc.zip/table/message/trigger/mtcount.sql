CREATE TRIGGER mtcount
AFTER INSERT ON message
FOR EACH ROW
  BEGIN 
    UPDATE theme SET count=count+1 WHERE theid=new.theid;
  END;
