CREATE TRIGGER ic
AFTER INSERT ON message
FOR EACH ROW
  BEGIN
    INSERT INTO `count` (msgid, accesscount, replycount) VALUES (NEW.msgid,0,0);
  END;
